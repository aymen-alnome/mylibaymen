def SumAymen(a,b):
    return a + b 

def SubAymen(a,b):
    return a - b 

def multAymen(a,b):
    return a * b 

def divAymen(a,b):
    return a / b 