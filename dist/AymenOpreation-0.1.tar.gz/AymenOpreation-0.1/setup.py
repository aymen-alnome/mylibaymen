import setuptools 
setuptools.setup(
    name='AymenOpreation',
    version='0.1',
    author= ' Aymen-Alnomi',
    description= ' Simple Library in python for test',
    packages= setuptools.find_packages(),
    classifiers=[
        "Programming Lanaguage :: python :: 3 ",
        "Operating System :: OS Independent ",
        " License :: OSI Approved :: MIT License",
    ]

)